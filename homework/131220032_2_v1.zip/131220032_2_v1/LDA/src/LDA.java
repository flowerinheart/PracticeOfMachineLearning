import java.io.FileNotFoundException;
import java.util.ArrayList;

import Jama.Matrix;


public class LDA {
	
	private ArrayList<ArrayList<ArrayList<Double>>> traindata = null;
	private ArrayList<ArrayList<ArrayList<Double>>> testdata = null;
	private int categoryKinds;
	private ArrayList<ArrayList<Double>> means = null;
	
	
	public LDA(ArrayList<ArrayList<ArrayList<Double>>> traindata,ArrayList<ArrayList<ArrayList<Double>>> testdata){
		this.setTraindata(traindata);
		this.setTestdata(testdata);
		categoryKinds = traindata.size();
	}
	
	public LDA(){};
	public static void main(String[] args) throws FileNotFoundException  {
		// TODO Auto-generated method stub
		
		ArrayList<ArrayList<ArrayList<Double>>> data = MatrixTools.readFromTxt("��������3.0a.txt");
		LDA lda = new LDA(data, data);
		lda.classify();
	}
	
    private double error_rate = 0.0;

    public double getER()
    {
	    return error_rate;
    }
    
    
    
    /**
     * @author Mhj
     */
	public void classify(){
		if(getTraindata() == null) return;
		ArrayList<Double> w = getW();
		
		
		//����ÿ��instance��ͶӰ�;�ֵ��ͶӰ
		int count = 0;
		for(ArrayList<ArrayList<Double>> cla : testdata)
			count += cla.size();
		double Y[] = new double[count];
		int i1 = 0;
		for(ArrayList<ArrayList<Double>> cla : testdata)
			for(ArrayList<Double> instance : cla)
				Y[i1++] = MatrixTools.mulVector2(w, instance);
		
		double meanY[] = new double[2];
		meanY[0] = MatrixTools.mulVector2(w, means.get(0));
		meanY[1] = MatrixTools.mulVector2(w, means.get(1));
		
		
		
		//���ݺ;�ֵͶӰ��ľ���������
		int errornum = 0;
		i1 = 0;
		int prediction[] = new int[count];
		for(int i = 0; i < 2; i++){
			ArrayList<ArrayList<Double>> cla = testdata.get(i);
			int n1 = cla.size();
			for(int k1 = 0; k1 < n1; k1++){
				if(Math.abs(Y[i1] - meanY[0]) < Math.abs(Y[i1] - meanY[1]))
					prediction[i1] = 0;
				else
					prediction[i1] = 1;
				errornum = prediction[i1] == i ? errornum : errornum + 1;
				i1++;
			}
		}
		if(i1 == 0)
			System.out.println("errpr");
		error_rate = errornum / (double)i1;
		return;
	}
	
	public ArrayList<Double> getW(){
		if(categoryKinds != 2)
			return null;
		if(means == null){
			means = new ArrayList<ArrayList<Double>>(categoryKinds);
			for(int i = 0; i < categoryKinds; i++)
				means.add(new ArrayList<Double>());
		}
		
		
		Matrix Sw = new Matrix(getTraindata().get(0).get(0).size(), getTraindata().get(0).get(0).size(), 0);
		for(int i = 0 ; i < categoryKinds; i++){
			means.set(i, MatrixTools.means(getTraindata().get(i)));
			for(ArrayList<Double> x : getTraindata().get(i)){
				ArrayList<Double> tempv = MatrixTools.vectorSub(x, means.get(i));
			    ArrayList<ArrayList<Double>> tempmat = MatrixTools.mulVector1(tempv, tempv);
			    double[][] t = new double[tempmat.size()][tempmat.get(0).size()];
			    for(int k1 = 0; k1 < tempmat.size(); k1++)
			    	for(int k2 = 0; k2 < tempmat.get(0).size(); k2++)
			    		t[k1][k2] = tempmat.get(k1).get(k2);
			    Matrix tmat = new Matrix(t);
			    Sw.plusEquals(tmat);
			    }
			}
		
		
		ArrayList<Double> newmean = MatrixTools.vectorSub(means.get(0), means.get(1));
		Sw = Sw.inverse();
		ArrayList<Double> res = new ArrayList<Double>();
		for(int i = 0; i < Sw.getRowDimension(); i++){
			res.add(0.0);
			for(int j = 0; j < newmean.size(); j++)
				res.set(i, Sw.get(i, j) * newmean.get(j) + res.get(i));
		}
			
		return res;
	}

	public ArrayList<ArrayList<ArrayList<Double>>> getTraindata() {
		return traindata;
	}

	public void setTraindata(ArrayList<ArrayList<ArrayList<Double>>> traindata) {
		this.traindata = traindata;
		categoryKinds = traindata.size();
	}

	public ArrayList<ArrayList<ArrayList<Double>>> getTestdata() {
		return testdata;
	}

	public void setTestdata(ArrayList<ArrayList<ArrayList<Double>>> testdata) {
		this.testdata = testdata;
		categoryKinds = testdata.size();
	}
}
