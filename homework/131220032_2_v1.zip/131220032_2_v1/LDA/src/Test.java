import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;


public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<ArrayList<Double>>> data;
		double res1, res2;
		 ArrayList<Double> meanER, SD;
		 
		 //ʮ�۽���
	    data = MatrixTools.readFromCsv("fourclass.csv");//readFromTxt("��������3.0a.txt");
		//ArrayList<Double> ER = hold_out(10, data);
	    meanER = new ArrayList<Double>();SD = new ArrayList<Double>();
	    crossValidation(10, data, 10, meanER, SD);
	    
	    res1 = MatrixTools.mean(meanER);
	    res2 = MatrixTools.mean(SD);
	    System.out.printf("�����ʵľ�ֵ��%f%%, ��׼����%f\n", res1  * 100, res2);
	    
	    data = MatrixTools.readFromCsv("heart.csv");//readFromTxt("��������3.0a.txt");
	    meanER = new ArrayList<Double>(); SD = new ArrayList<Double>();
	    crossValidation(10, data, 10, meanER, SD);
	    
	    res1 = MatrixTools.mean(meanER);
	    res2 = MatrixTools.mean(SD);
	    System.out.printf("�����ʵľ�ֵ��%f%%, ��׼����%f\n", res1  * 100, res2);
	    
	    
	    int count = 0;
	    //��һ��
	    data = MatrixTools.readFromCsv("fourclass.csv");//readFromTxt("��������3.0a.txt");
	    count = 0;
	    for(ArrayList<ArrayList<Double>> cla : data)
	    	count += cla.size();
		//ArrayList<Double> ER = hold_out(10, data);
	    meanER = new ArrayList<Double>();SD = new ArrayList<Double>();
	    crossValidation(1, data, count, meanER, SD);
	    
	    res1 = MatrixTools.mean(meanER);
	    res2 = MatrixTools.mean(SD);
	    System.out.printf("�����ʵľ�ֵ��%f%%, ��׼����%f\n", res1  * 100, res2);
	    
	    

	    data = MatrixTools.readFromCsv("heart.csv");//readFromTxt("��������3.0a.txt");
	    
	    count = 0;
	    for(ArrayList<ArrayList<Double>> cla : data)
	    	count += cla.size();
	    meanER = new ArrayList<Double>(); SD = new ArrayList<Double>();
	    crossValidation(1, data, count, meanER, SD);
	    
	    res1 = MatrixTools.mean(meanER);
	    res2 = MatrixTools.mean(SD);
	    System.out.printf("�����ʵľ�ֵ��%f%%, ��׼����%f\n", res1  * 100, res2);
	    
	    
	    
	    
	}
	static double  proportion = 0.7;

	

	//ʹ�÷ֲ�����ķ�����ȡ7:3������ѵ�����Ͳ��Լ�
	public static ArrayList<Double> hold_out(int testtime,  ArrayList<ArrayList<ArrayList<Double>>> data){
		ArrayList<ArrayList<ArrayList<Double>>> traindata = new ArrayList<ArrayList<ArrayList<Double>>>(), 
				testdata = new ArrayList<ArrayList<ArrayList<Double>>>();
		LDA lda = new LDA();
		ArrayList<Double> ER = new ArrayList<Double>();
		for(int i = 0; i < testtime; i++){ //����10�ʻ�������
			int n = data.size();
			for(int k1 = 0; k1 < n; k1++){
				ArrayList<ArrayList<Double>> mct = data.get(k1);//��ȡÿ�����
				Collections.shuffle(mct);
				if(traindata.size() <= k1){
				    traindata.add(new ArrayList<ArrayList<Double>>());
				    testdata.add(new ArrayList<ArrayList<Double>>());
				}
				
				
				int m = mct.size();
				int k = (int) Math.round(m * proportion);
				ArrayList<ArrayList<Double>> ct1 = traindata.get(k1);
				ArrayList<ArrayList<Double>> ct2 = testdata.get(k1);
				int c1 = 0, c2 = 0;
				for(int k2 = 0; k2 < m; k2++){
					
					if(k2 < k){
						if(ct1.size() <= c1)
						    ct1.add(mct.get(k2));
						else
							ct1.set(c1, mct.get(k2));
						c1++;
					}
					else{
						if(ct2.size() <= c2)
						    ct2.add(mct.get(k2));
						else
							ct2.set(c2, mct.get(k2));
						c2++;
					}
				}
			}
			
			//���ݼ�������ϣ�ʹ����LDA����ģ�ͷ���
			lda.setTraindata(traindata);
			lda.setTestdata(testdata);
			lda.classify();
			if(ER.size() <= i)
			    ER.add(lda.getER());
			else
				ER.set(i, lda.getER());
		}
		
		return ER;
	}
	
	
	
	public static void crossValidation(int testtime, ArrayList<ArrayList<ArrayList<Double>>> data, int k, ArrayList<Double> meanER, ArrayList<Double> SD){
		LDA lda = new LDA();
		//�������ݼ�
		ArrayList<Double> ER = new ArrayList<Double>();
		ArrayList<ArrayList<ArrayList<Double>>> traindata = new ArrayList<ArrayList<ArrayList<Double>>>(),
				testdata = new ArrayList<ArrayList<ArrayList<Double>>>();
		
		
		for(int t = 0; t < testtime; t++){
		for(ArrayList<ArrayList<Double>> cla : data)
			Collections.shuffle(cla);
		
		
		
		for(int i = 0; i < k; i++){//��i����֤
			//����i��k����ѵ�����ݼ��Ͳ������ݼ�

			divideToTT(data, k, i, testdata, traindata);
			
			//ͨ��ѵ���Ͳ������ݼ���ѵ��ģ�ͼ��������
			lda.setTraindata(traindata);
			lda.setTestdata(testdata);
			lda.classify();
			if(i >= ER.size())
			    ER.add(lda.getER());
			else
				ER.set(i, lda.getER());
			
		}
		
		double mean = MatrixTools.mean(ER);
		double sd = MatrixTools.getSD(ER, mean);
		
		meanER.add(mean);
		SD.add(sd);
		}
	}

	
	

	private static void divideToTT(
			ArrayList<ArrayList<ArrayList<Double>>> data, int k, int i,
			ArrayList<ArrayList<ArrayList<Double>>> testdata,
			ArrayList<ArrayList<ArrayList<Double>>> traindata) {
		// TODO Auto-generated method stub
		
		testdata.clear();
		//traindata.clear();
		int count = 0;
		for(int i1 = 0; i1 < data.size(); i1++){		
			if(traindata.size() <= i1)
				traindata.add(new ArrayList<ArrayList<Double>>());
			if(testdata.size() <= i1)
				testdata.add(new ArrayList<ArrayList<Double>>());
			
			ArrayList<ArrayList<Double>> cla = data.get(i1);
			ArrayList<ArrayList<Double>> traincla = traindata.get(i1);
			ArrayList<ArrayList<Double>> testcla = testdata.get(i1);
			
			int n1 = cla.size();
			int h1 = 0, h2 = 0;
			for(int i2 = 0; i2 < n1; i2++){
				ArrayList<Double> instacne = cla.get(i2);
				if(n1 >= k){
				if(i2 >= (n1 / k) * i && i2 < (n1 / k) * ( i + 1)){
					if(testcla.size() <= h1)
						testcla.add(instacne);
					else
						testcla.set(h1, instacne);
					h1++;
				}else{
					if(traincla.size() <= h2)
						traincla.add(instacne);
					else
						traincla.set(h2, instacne);
					h2++;
				}
				}else{
					if(count == i)
						MatrixTools.addE(testcla, instacne, h1++);
					else
						MatrixTools.addE(traincla, instacne, h2++);
				}
				count++;
					
			}
		}
	}
}
