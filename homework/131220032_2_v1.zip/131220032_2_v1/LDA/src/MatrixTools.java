import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class MatrixTools {

	private static Scanner sc;



	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static double mean(double[] data){
		double sum = 0;
		for(double d : data)
			sum += d;
		return sum / data.length;
	}
	
	public static double mean(ArrayList<Double> data){
		double sum = 0;
		for(double d : data)
			sum += d;
		return sum / data.size();
	}
	
	public static double getSD(ArrayList<Double> data, double mean){
		double sum = 0;
		for(double d : data)
			sum += Math.pow(d - mean, 2);
		return Math.sqrt(sum / data.size());
	}
	
	public static double getSD(double[] data, double mean){
		double sum = 0;
		for(double d : data)
			sum += Math.pow(d - mean, 2);
		return Math.sqrt(sum / data.length);
	}

	
	//��ֵ����
	public  static ArrayList<Double> means(ArrayList<ArrayList<Double>> category)
	{
		ArrayList<Double> sum = new ArrayList<Double>();
		for(ArrayList<Double> x : category)
			for(int i = 0; i < x.size(); i++)
				if(i == sum.size())
					sum.add(x.get(i));
				else
					sum.set(i, sum.get(i) + x.get(i));

		for(int i = 0; i < sum.size(); i++)
			sum.set(i, sum.get(i) / category.size());
		
		return sum;
	}
	
	//��������������
	public static ArrayList<ArrayList<Double>> mulVector1(ArrayList<Double> v1, ArrayList<Double> v2){
		if(v1.size() != v2.size()) return null;
		ArrayList<ArrayList<Double>> res = new ArrayList<ArrayList<Double>>();
		
		for(int i = 0; i < v1.size(); i ++){
			res.add(new ArrayList<Double>());
			for(int j = 0; j < v1.size(); j++)
				res.get(i).add(v1.get(i) * v2.get(j));
		}
		return res;
	}
	
	//��������������
	public static double mulVector2(ArrayList<Double> v1, ArrayList<Double> v2){
		if(v1.size() != v2.size()) return -1;
		double res = 0;
		
		for(int i = 0; i < v1.size(); i ++)
			res += v1.get(i) * v2.get(i);
		
		return res;
	}
	
	//�������
	public static ArrayList<Double> vectorSub(ArrayList<Double> v1, ArrayList<Double> v2){
		if(v1.size() != v2.size()) return null;
		ArrayList<Double> res = new ArrayList<Double>();
		
		for(int i = 0; i < v1.size(); i ++)
			res.add(v1.get(i) - v2.get(i));
		
		return res;
	}
	
	
	public static ArrayList<Double> vectorAdd(ArrayList<Double> v1, ArrayList<Double> v2){
		if(v1.size() != v2.size()) return null;
		ArrayList<Double> res = new ArrayList<Double>();
		
		for(int i = 0; i < v1.size(); i ++)
			res.add(v1.get(i) + v2.get(i));
		
		return res;
	}
	
	
	
	//��txt�ж�ȡ����
	public static ArrayList<ArrayList<ArrayList<Double>>> readFromTxt(String filename) throws FileNotFoundException{
		ArrayList<ArrayList<ArrayList<Double>>> res = new ArrayList<ArrayList<ArrayList<Double>>>();
		File f = new File(filename);
		sc = new Scanner(f,"UTF-8");
		sc.nextLine();
		sc.nextLine();
		while(sc.hasNext())
		{
			String[] ss = sc.nextLine().trim().split("[ ]+");
			//����
			int no = -1;
			if(ss[ss.length - 1].equals("��"))
				no = 0;
				
			if(ss[ss.length - 1].equals("��"))
				no = 1;
			if(no == -1)
				return null;
			ArrayList<Double> item = new ArrayList<Double>();
			item.add(Double.valueOf(ss[1]));
			item.add(Double.valueOf(ss[2]));
			while(no >= res.size()) {
				res.add(new ArrayList<ArrayList<Double>>());
			}
			res.get(no).add(item);
		}
		
		return res;
	}
	
	public static ArrayList<ArrayList<ArrayList<Double>>> readFromCsv(String filename) throws FileNotFoundException{
		ArrayList<ArrayList<ArrayList<Double>>> res = new ArrayList<ArrayList<ArrayList<Double>>>();
		File f = new File(filename);
		sc = new Scanner(f,"UTF-8");
		while(sc.hasNext())
		{
			String[] ss = sc.nextLine().trim().split(",");
			//����
			int no = -1;
			if(ss[ss.length - 1].equals("1"))
				no = 0;
				
			if(ss[ss.length - 1].equals("-1"))
				no = 1;
			if(no == -1)
				return null;
			ArrayList<Double> item = new ArrayList<Double>();
			for(int i = 0; i < ss.length - 1; i++)
				item.add(Double.valueOf(ss[i]));
			while(no >= res.size()) 
				res.add(new ArrayList<ArrayList<Double>>());
			res.get(no).add(item);
		}
		
		return res;
	}
	
	
	public static void addE(ArrayList<Double> list, double data, int i){
		if(list.size() <= i)
			list.add(data);
		else
			list.set(i, data);
	}
	
	
	public static void addE(ArrayList<ArrayList<Double>> list, ArrayList<Double> data, int i){
		if(list.size() <= i)
			list.add(data);
		else
			list.set(i, data);
	}
}
