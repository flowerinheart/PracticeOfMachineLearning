package tools;

public class Tools {

	public static void p(Object o)
	{
		System.out.print(o);
	}
	
	public static void p(int i)
	{
		System.out.print(i);
	}
}
