import java.util.ArrayList;


public class Vector {
	
	private ArrayList<Double> data;
	public Vector()
	{
		data = new ArrayList<Double>();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	int size()
	{
		return data.size();
	}
	
	double mean()
	{
		double s = 0;
		for(int i = 0; i < this.size(); i++)
			s += data.get(i);
		return s / this.size();
	}

}
