"""
----
"""
import numpy as np
import sys as sys


class MultinomialNB(object):
    """
	Naive Bayes classifier for multinomial models
        The multinomial Naive Bayes classifier is suitable for classification with
        discrete features
	
	Parameters
        ----------
        alpha : float, optional (default=1.0)
                Setting alpha = 0 for no smoothing
		Setting 0 < alpha < 1 is called Lidstone smoothing
		Setting alpha = 1 is called Laplace smoothing 
        fit_prior : boolean
                Whether to learn class prior probabilities or not.
                If false, a uniform prior will be used.
        class_prior : array-like, size (n_classes,)
                Prior probabilities of the classes. If specified the priors are not
                adjusted according to the data.
		
	Attributes
        ----------
        fit(X,y):
                X and y are array-like, represent features and labels.
                call fit() method to train Naive Bayes classifier.
        
        predict(X):
                
	
	"""

    def __init__(self, alpha=1.0, fit_prior=True, class_prior=None):
        self.alpha = alpha
        self.fit_prior = fit_prior
        self.class_prior = class_prior
        self.classes = None
        self.conditional_prob = None
        self.featureClassLabel = None


    class_info = {}
    def _calculate_feature_prob(self, subDataSet, class_no, i):
        feature = list(l[i] for l in subDataSet)
        values = np.unique(feature)
        total_num = float(len(feature))
        if self.class_info.get(class_no) is None:
            self.class_info[class_no] = {}
        if self.class_info[class_no].get(i) is None:
            self.class_info[class_no][i] = (total_num + len(values) * self.alpha)
        value_prob = {}
        for v in values:
            value_prob[v] = ((np.sum(np.equal(feature, v)) + self.alpha) /
                             (total_num + len(values) * self.alpha))
        return value_prob

    def fit(self, X, y, labels):
        # TODO: check X,y

        self.featureClassLabel = labels
        self.classes = np.unique(y)
        # calculate class prior probabilities: P(y=ck)
        if self.class_prior is None:
            class_num = len(self.classes)
            if not self.fit_prior:
                self.class_prior = [1.0 / class_num for _ in range(class_num)]  # uniform prior
            else:
                self.class_prior = []
                sample_num = float(len(y))
                for c in self.classes:
                    c_num = np.sum(np.equal(y, c))
                    self.class_prior.append(
                        (c_num + self.alpha) / (sample_num + class_num * self.alpha))

        # calculate Conditional Probability: P( xj | y=ck )
        self.conditional_prob = {}  # like { c0:{ x0:{ value0:0.2, value1:0.8 }, x1:{} }, c1:{...} }
        for c in self.classes:
            self.conditional_prob[c] = {}
            feature = X[np.equal(y, c)]
            for i in range(len(X[0])):  # for each feature
                self.conditional_prob[c][i] = self._calculate_feature_prob(feature, c, i)
        return self

    # given values_prob {value0:0.2,value1:0.1,value3:0.3,.. } and target_value
    # return the probability of target_value
    def _get_xj_prob(self, values_prob, class_no, i, target_value):
        if values_prob.get(target_value) == None:
            return (0 + self.alpha) / self.class_info[class_no][i]
        return values_prob[target_value]


    # predict a single sample based on (class_prior,conditional_prob)
    def _predict_single_sample(self, x):
        label = -1
        max_posterior_prob = 0

        # for each category, calculate its posterior probability: class_prior * conditional_prob
        for c_index in range(len(self.classes)):
            current_class_prior = self.class_prior[c_index]
            current_conditional_prob = 1.0
            feature_prob = self.conditional_prob[self.classes[c_index]]
            j = 0
            for feature_i in feature_prob.keys():
                current_conditional_prob *= self._get_xj_prob(feature_prob[feature_i], c_index, j, x[j])
                j += 1

            # compare posterior probability and update max_posterior_prob, label
            if current_class_prior * current_conditional_prob > max_posterior_prob:
                max_posterior_prob = current_class_prior * current_conditional_prob
                label = self.classes[c_index]
        return label

    # predict samples (also single sample)
    def predict(self, X):
        # TODO1:check and raise NoFitError
        # ToDO2:check X
            # classify each sample
        labels = []
        for i in range(len(X)):
            label = self._predict_single_sample(X[i])
            labels.append(label)
        return labels


# GaussianNB differ from MultinomialNB in these two method:
# _calculate_feature_prob, _get_xj_prob
class GaussianNB(MultinomialNB):
    """
        GaussianNB inherit from MultinomialNB,so it has self.alpha
        and self.fit() use alpha to calculate class_prior
        However,GaussianNB should calculate class_prior without alpha.
        Anyway,it make no big different

        """

    # calculate mean(mu) and standard deviation(sigma) of the given feature
    def _calculate_feature_prob(self, subDataSet, class_no, i):
        feature = list(l[i] for l in subDataSet)
        mu = np.mean(feature)
        sigma = np.std(feature)
        if sigma == 0:
            sigma = 0.0001
        return (mu, sigma)

    # the probability density for the Gaussian distribution
    def _prob_gaussian(self, mu, sigma, x):
        res = (1.0 / (sigma * np.sqrt(2 * np.pi))) * np.exp(- (x - mu) ** 2 / (2 * sigma ** 2))
        return res
    # given mu and sigma , return Gaussian distribution probability for target_value
    def _get_xj_prob(self, mu_sigma, class_no, i, target_value):
        return self._prob_gaussian(mu_sigma[0], mu_sigma[1], target_value)



class MixtureNB(MultinomialNB):
    """
        GaussianNB inherit from MultinomialNB,so it has self.alpha
        and self.fit() use alpha to calculate class_prior
        However,GaussianNB should calculate class_prior without alpha.
        Anyway,it make no big different

        """

    # calculate mean(mu) and standard deviation(sigma) of the given feature
    def _calculate_feature_prob(self, subDataSet, class_no, i):
        feature = list(l[i] for l in subDataSet)
        if self.featureClassLabel[i] == 0:
            values = np.unique(feature)
            total_num = float(len(feature))
            value_prob = {}
            for v in values:
                value_prob[v] = ((np.sum(np.equal(feature, v)) + self.alpha) /
                                 (total_num + len(values) * self.alpha))
            return value_prob
        else:
            mu = np.mean(feature)
            sigma = np.std(feature)
            return (mu, sigma)

    # the probability density for the Gaussian distribution
    def _prob_gaussian(self, mu, sigma, x):
        return (1.0 / (sigma * np.sqrt(2 * np.pi)) *
                np.exp(- (x - mu) ** 2 / (2 * sigma ** 2)))

    # given mu and sigma , return Gaussian distribution probability for target_value
    def _get_xj_prob(self, values_prob, class_no, i, target_value):
        if self.featureClassLabel[i] == 0:
            return values_prob[target_value]
        else:
            return self._prob_gaussian(values_prob[0], values_prob[1], target_value)

def readFromFile(fileName, flag):
    """

    :param fileName:
    :return:
        X, labels, Y, symbol_table
    """
    X = []; symbol_table = {}; Y = []; labels = [];counts = []
    first = True

    for line in open(fileName): # each line

        splits = line.strip("\r\n").split(",")
        #read feature and featureClassLabel
        feature = []; length = len(splits)
        for i in range(length - 1):
            if first:
                counts.append(0)
            str = splits[i].strip("\\'"); label = 0
            #if str.isdigit():
             #   feature.append(float(str))
              #  label = 1
            #else:
            #try:
            #    number = float(str)
            #    feature.append(number)
            #    label = 1
            #except ValueError:
            if flag:
                feature.append(float(str))
                label = 1
            else:
                if first:
                   symbol_table[i] = {}
                if symbol_table[i].get(str) == None:
                    symbol_table[i][str] = counts[i]
                    counts[i] += 1
                feature.append(symbol_table[i][str])
            if first:
                labels.append(label)
        X.append(feature)


        #read sample_label
        str = splits[-1].strip("\\'")
        if first:
            counts.append(0)
            symbol_table[length - 1] = {}
        if symbol_table[length - 1].get(str) == None:
            symbol_table[length - 1][str] = counts[length - 1]
            counts[length - 1] += 1
        Y.append(symbol_table[length - 1][str])
        first = False

    return X, labels, Y, symbol_table
if __name__ == "__main__":
    nb = MixtureNB()
    res = readFromFile("../data/breast-cancer.csv", False)#("../data/glass.csv")
    nb.fit(np.array(res[0]), np.array(res[2]), res[1])

