import NaiveBayes as NB
import numpy as np
import CrossValidation as CV
if __name__ == "__main__":
    nb1 = NB.MultinomialNB()
    nb2 = NB.GaussianNB()
    res1 = NB.readFromFile("../data/breast-cancer.csv", False)
    res2 = NB.readFromFile("../data/glass.csv", True)
    ER1 = []; ER2 = [];
    for i in range(5):
        ER1.append(CV.crossValidation(res1[0], res1[2], 10, nb1))
        ER2.append(CV.crossValidation(res2[0], res2[2], 10, nb2))
    print(ER1, np.mean(ER1))

    print(ER2, np.mean(ER2))