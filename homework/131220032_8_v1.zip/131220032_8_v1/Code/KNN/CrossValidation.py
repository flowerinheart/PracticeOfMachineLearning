"""
---
"""
#-*-coding:utf-8-*-
import numpy as np
import random
from os import listdir
from Tools.tools import *


def crossValidation(X, y, n, model):
    """

    :param n:
    :param model:
    :param X:
    :param y:
    :return:
    """
    TX = list(X)
    for i in range(len(X)):
        TX[i].append(y[i])

    ER = []
    random.shuffle(TX)
    Ty = []
    for j in range(len(TX)):
        Ty.append(TX[j][-1])
        del TX[j][-1]

    for i in range(n):
        block_size = int(len(TX) / n)

        transX = [];
        transy = [];
        testX = [];
        testy = []
        lo = i * block_size;
        hi = (i + 1) * block_size
        for j in range(len(TX)):
            if lo <= j < hi:
                testX.append(TX[j])
                testy.append(Ty[j])
            else:
                transX.append(TX[j])
                transy.append(Ty[j])

        model.fit(np.array(transX), np.array(transy), None)
        labels = model.predict(testX)
        num = len(labels);
        err = 0
        for i in range(num):
            if labels[i] != testy[i]:
                err += 1
        ER.append(float(err) / float(num))

        # print(ER)
    return np.mean(np.array(ER))

import KNN

if __name__ == "__main__":
    knn = KNN.KNNModel(3)
    dir = "input/"
    filelist = listdir(dir)
    count = 5
    for file in filelist:
        if file.find("csv") != -1:
            args = readFromFile(dir + file, ",")
        else:
            args = readFromFile(dir + file)
        print file + ":"
        t = []
        sum = 0.0
        for i in range(count):
            t.append(crossValidation(args[0], args[2], 10, knn))
            sum += t[-1]
        print t
        print sum / count
