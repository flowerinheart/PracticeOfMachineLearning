#-*-coding:utf-8-*-
from numpy import *
import operator
from Tools.tools import *
from os import listdir


class KNNModel(Model):
    def __init__(self, k):
        self.dataSet = None
        self.lables = None
        self.k = k
    def classify0(self, inX, dataSet, labels, k):
        dataSetSize = dataSet.shape[0]
        diffMat = tile(inX, (dataSetSize,1)) - dataSet     #重复inX dataSetSize次
        sqDiffMat = diffMat**2
        sqDistances = sqDiffMat.sum(axis=1)
        distances = sqDistances**0.5
        sortedDistIndicies = distances.argsort()            #距离排序
        classCount={}
        for i in range(k):
            voteIlabel = labels[sortedDistIndicies[i]]
            classCount[voteIlabel] = classCount.get(voteIlabel,0) + 1
        sortedClassCount = sorted(classCount.iteritems(), key=operator.itemgetter(1), reverse=True)
        return sortedClassCount[0][0]    #票数最高的label




    def predict(self, X):
        labels = []
        for x in X:
            labels.append(self.classify0(x, self.dataSet, self.lables, self.k))
        return labels
    def fit(self, X, y, labels):
        self.dataSet = X
        self.lables = y

    def setk(self, k):
        self.k = k

def readDataSet(filename):
    dataset = []
    for line in open(filename):
        dataset.append(list(line.split(" ")))
    return dataset




