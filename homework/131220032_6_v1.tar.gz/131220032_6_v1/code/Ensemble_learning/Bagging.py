from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier

class Bagging:
    def __init__(self, estimator = DecisionTreeClassifier()):
        self.estimator = BaggingClassifier(estimator)

    def fit(self, X, y):
        self.estimator.fit(X, y)

    def predict(self, X):
        return self.estimator.predict(X)

    def set_base_estimator(self, estimator):
        self.estimator.base_estimator = estimator


