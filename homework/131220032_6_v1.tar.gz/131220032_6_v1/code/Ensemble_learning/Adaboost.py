'''
Adaboost algorithm
'''


import numpy as np
from sklearn import clone
from sklearn.tree import DecisionTreeClassifier
from Tools.tools import readFromFile

class Adaboost:
    def __init__(self, base_estimator = DecisionTreeClassifier(),
        n_estimators = 100,
        estimator_params = tuple(),
        learning_rate = 0.01,
        random_state = None):
        self.n_estimators = n_estimators
        self.estimators_ = []
        self.estimator_weights_ = []
        self.estimator_errors_ = []
        self.base_estimator_ = base_estimator
        self.learn_rate = learning_rate
        self.random_state = None
        self.estimator_params = estimator_params


    def set_base_estimator(self, estimator):
        self.base_estimator_ = estimator

    def fit(self, X, y, sample_weight = None):
        if sample_weight is None:
            # Initialize weights to 1 / n_samples
            sample_weight = np.empty(X.shape[0], dtype=np.float)
            sample_weight[:] = 1. / X.shape[0]
        self.estimators_ = []
        self.estimator_weights_ = np.zeros(self.n_estimators, dtype=np.float)
        self.estimator_errors_ = np.ones(self.n_estimators, dtype=np.float)
        for iboost in range(self.n_estimators):
            sample_weight, estimator_weight, estimator_error = self._boost(
                iboost,
                X, y,
                sample_weight)

            # Early termination
            if sample_weight is None:
                break

            self.estimator_weights_[iboost] = estimator_weight
            self.estimator_errors_[iboost] = estimator_error

            # Stop if error is zero
            if estimator_error == 0:
                break

            sample_weight_sum = np.sum(sample_weight)

            # Stop if the sum of sample weights has become non-positive
            if sample_weight_sum <= 0:
                break

            if iboost < self.n_estimators - 1:
                # Normalize
                sample_weight /= sample_weight_sum

            return self


    def _boost(self, iboost, X, y, sample_weight):
        """Implement a single boost using the SAMME discrete algorithm."""
        estimator = self._make_estimator()

        try:
            estimator.set_params(random_state=self.random_state)
        except ValueError:
            pass

        estimator.fit(X, y, sample_weight=sample_weight)

        y_predict = estimator.predict(X)

        if iboost == 0:
            self.classes_ = getattr(estimator, 'classes_', None)
            self.n_classes_ = len(self.classes_)

        # Instances incorrectly classified
        incorrect = y_predict != y

        # Error fraction
        estimator_error = np.mean(
            np.average(incorrect, weights=sample_weight, axis=0))

        # Stop if classification is perfect
        if estimator_error <= 0:
            return sample_weight, 1., 0.

        n_classes = self.n_classes_

        # Stop if the error is at least as bad as random guessing
        if estimator_error >= 1. - (1. / n_classes):
            self.estimators_.pop(-1)
            if len(self.estimators_) == 0:
                raise ValueError('BaseClassifier in AdaBoostClassifier '
                                 'ensemble is worse than random, ensemble '
                                 'can not be fit.')
        return None, None, None

        # Boost weight using multi-class AdaBoost SAMME alg
        estimator_weight = self.learning_rate * (
        np.log((1. - estimator_error) / estimator_error) +
        np.log(n_classes - 1.))

        # Only boost the weights if I will fit again
        if not iboost == self.n_estimators - 1:
            # Only boost positive weights
            sample_weight *= np.exp(estimator_weight * incorrect *
                                    ((sample_weight > 0) |
                                     (estimator_weight < 0)))

        return sample_weight, estimator_weight, estimator_error

    def _make_estimator(self):
        estimator = clone(self.base_estimator_)
        #estimator.set_params(**dict((p, getattr(self, p))
        #                            for p in self.estimator_params))


        self.estimators_.append(estimator)
        return estimator


    def predict(self, X):
        return self._get_median_predict(X, len(self.estimators_))
    def _get_median_predict(self, X, limit):
        # Evaluate predictions of all estimators
        predictions = np.array([
                                   est.predict(X) for est in self.estimators_[:limit]]).T

        # Sort the predictions
        sorted_idx = np.argsort(predictions, axis=1)

        # Find index of median prediction for each sample
        weight_cdf = self.estimator_weights_[sorted_idx].cumsum(axis=1)
        median_or_above = weight_cdf >= 0.5 * weight_cdf[:, -1][:, np.newaxis]
        median_idx = median_or_above.argmax(axis=1)

        median_estimators = sorted_idx[np.arange(X.shape[0]), median_idx]

        # Return median predictions
        return predictions[np.arange(X.shape[0]), median_estimators]



from Ensemble_learning.CrossValidation import crossValidation
if __name__ == "__main__":
    data, label, targets, symtable = readFromFile("input/glass.csv", ",")
    clf = Adaboost(n_estimators=100, learning_rate=.007)
    #scores = cross_val_score(clf, data, targets)
    print ("Adaboost error rate: " + str(crossValidation(data, targets, 10, clf)))




