def readFromFile(fileName, t = " ", flag = True):
    """

    :param fileName:
    :return:
        X, labels, Y, symbol_table
    """
    X = []; symbol_table = {}; Y = []; labels = [];counts = []
    first = True

    for line in open(fileName): # each line


        if t == " ":
            splits = line.strip("\r\n").split()
        else:
            splits = line.strip("\r\n").split(t)
        #read feature and featureClassLabel
        feature = []; length = len(splits)
        for i in range(length - 1):
            if first:
                counts.append(0)
            str = splits[i].strip("\\'"); label = 0
            #if str.isdigit():
             #   feature.append(float(str))
              #  label = 1
            #else:
            #try:
            #    number = float(str)
            #    feature.append(number)
            #    label = 1
            #except ValueError:
            if flag:
                feature.append(float(str))
                label = 1
            else:
                if first:
                   symbol_table[i] = {}
                if symbol_table[i].get(str) == None:
                    symbol_table[i][str] = counts[i]
                    counts[i] += 1
                feature.append(symbol_table[i][str])
            if first:
                labels.append(label)
        X.append(feature)


        #read sample_label
        str = splits[-1].strip("\\'")
        if first:
            counts.append(0)
            symbol_table[length - 1] = {}
        if symbol_table[length - 1].get(str) == None:
            symbol_table[length - 1][str] = counts[length - 1]
            counts[length - 1] += 1
        Y.append(symbol_table[length - 1][str])
        first = False

    return X, labels, Y, symbol_table


class Model:
    def fit(self, X, y, labels):
        raise NotImplementedError

    def predict(self, X):
        raise NotImplementedError
