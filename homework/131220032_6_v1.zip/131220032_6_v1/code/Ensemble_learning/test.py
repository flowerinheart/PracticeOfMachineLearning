from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from Adaboost import Adaboost
from Tools.tools import readFromFile
from Bagging import Bagging
from CrossValidation import crossValidation


base_classifier1 = DecisionTreeClassifier(max_depth=1)
base_classifier2 = GaussianNB()
adaboost_classifier = Adaboost()
bagging_classifier = Bagging()
def test(data, targets, filename):
    adaboost_classifier.set_base_estimator(base_classifier1)
    bagging_classifier.set_base_estimator(base_classifier1)
    print ("DT " + filename + " error rate: " + str(crossValidation(data, targets, 10, base_classifier1)))
    print ("adaboost DT " + filename + " error rate: " + str(crossValidation(data, targets, 10, adaboost_classifier)))
    print ("bagging DT " + filename + " error rate: " + str(crossValidation(data, targets, 10, bagging_classifier)))

    adaboost_classifier.set_base_estimator(base_classifier2)
    bagging_classifier.set_base_estimator(base_classifier2)
    print ("NB " + filename + " error rate: " + str(crossValidation(data, targets, 10, base_classifier2)))
    print ("adaboost NB " + filename + " error rate: " + str(crossValidation(data, targets, 10, adaboost_classifier)))
    print ("bagging NB " + filename + " error rate: " + str(crossValidation(data, targets, 10, bagging_classifier)))

if __name__ == "__main__":
    data1, _, targets1, _ = readFromFile("input/glass.csv", ",")
    data2, _, targets2, _ = readFromFile("input/breast-cancer.csv", ",", False)
    file1 = "glass.csv"
    file2 = "breast-cancer.csv"

    test(data1, targets1, file1)
    test(data2, targets2, file2)






