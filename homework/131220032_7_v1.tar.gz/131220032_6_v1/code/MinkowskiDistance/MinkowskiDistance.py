import numpy as np
import math
def distance(a, b, p):
    k = 0.0
    for xi,yi in zip(a, b):
        k += abs(xi - yi) ** p
    if p == 1:
        return k
    else:
        return k ** (1.0 / p)


def readfromfile(filename):
    i = 0
    data_set = []
    file = open(filename)
    for line in file:
        if i < 2:
            i += 1
            continue
        t = line.strip().split()
        data_set.append([float(t[1]), float(t[2])])
    return data_set

def run(data_set, p):
    #data_set = readfromfile("input/ttt.txt")
    # length = len(data_set)
    length = 8
    size = 8
    for i in range(length + 1):
        if i != 0:
            a = data_set[i - 1]
        t = ""
        for j in range(length + 1):
            if i == 0 and j == 0:
                t += " " * size
                continue
            else:
                if i == 0:
                    t += str(j).rjust(size)
                    continue
                if j == 0:
                    t += str(i).rjust(size)
                    continue
            b = data_set[j - 1]
            dis = round(distance(a, b, p), 4)
            t += str(dis).rjust(size)
        print t


if __name__ == "__main__":
    data_set = readfromfile("input/ttt.txt")
    for p in range(1,4):
        run(data_set, p)
