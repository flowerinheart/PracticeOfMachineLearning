# coding=utf-8

import numpy as np
import os

import sys


class KMeans(object):
    """
    - 参数
        n_clusters:
            聚类个数，即k
        initCent:
            质心初始化方式，可选"random"或指定一个具体的array,默认random，即随机初始化
        max_iter:
            最大迭代次数
    """

    def __init__(self, n_clusters=5, initCent='random', max_iter=300):
        if hasattr(initCent, '__array__'):
            n_clusters = initCent.shape[0]
            self.centroids = np.asarray(initCent, dtype=np.float)
        else:
            self.centroids = None

        self.n_clusters = n_clusters
        self.max_iter = max_iter
        self.initCent = initCent
        self.clusterAssment = None
        self.labels = None
        self.sse = None
        self.dataset = None

        # 计算两点的欧式距离

    def _distEclud(self, vecA, vecB):
        return np.linalg.norm(vecA - vecB)

    # 随机选取k个质心,必须在数据集的边界内
    def _randCent(self, X, k):
        n = X.shape[1]  # 特征维数
        centroids = np.empty((k, n))  # k*n的矩阵，用于存储质心
        for j in range(n):  # 产生k个质心，一维一维地随机初始化
            minJ = min(X[:, j])
            rangeJ = float(max(X[:, j]) - minJ)
            centroids[:, j] = (minJ + rangeJ * np.random.rand(k, 1)).flatten()
        return centroids

    def fit(self, X):
        # 类型检查
        self.dataset = X
        if not isinstance(X, np.ndarray):
            try:
                X = np.asarray(X)
            except:
                raise TypeError("numpy.ndarray required for X")

        m = X.shape[0]  # m代表样本数量
        self.clusterAssment = np.empty((m, 2))  # m*2的矩阵，第一列存储样本点所属的族的索引值，
        # 第二列存储该点与所属族的质心的平方误差
        if self.initCent == 'random':
            self.centroids = self._randCent(X, self.n_clusters)

        clusterChanged = True
        for _ in range(self.max_iter):
            clusterChanged = False
            for i in range(m):  # 将每个样本点分配到离它最近的质心所属的族
                minDist = np.inf;
                minIndex = -1
                for j in range(self.n_clusters):
                    distJI = self._distEclud(self.centroids[j, :], X[i, :])
                    if distJI < minDist:
                        minDist = distJI;
                        minIndex = j
                if self.clusterAssment[i, 0] != minIndex:
                    clusterChanged = True
                    self.clusterAssment[i, :] = minIndex, minDist ** 2

            if not clusterChanged:  # 若所有样本点所属的族都不改变,则已收敛，结束迭代
                break
            for i in range(self.n_clusters):  # 更新质心，即将每个族中的点的均值作为质心
                ptsInClust = X[np.nonzero(self.clusterAssment[:, 0] == i)[0]]  # 取出属于第i个族的所有点
                self.centroids[i, :] = np.mean(ptsInClust, axis=0)

        self.labels = self.clusterAssment[:, 0]
        self.sse = sum(self.clusterAssment[:, 1])

    def predict(self, X):  # 根据聚类结果，预测新输入数据所属的族
        # 类型检查
        if not isinstance(X, np.ndarray):
            try:
                X = np.asarray(X)
            except:
                raise TypeError("numpy.ndarray required for X")

        m = X.shape[0]  # m代表样本数量
        preds = np.empty((m,))
        for i in range(m):  # 将每个样本点分配到离它最近的质心所属的族
            minDist = np.inf
            for j in range(self.n_clusters):
                distJI = self._distEclud(self.centroids[j, :], X[i, :])
                if distJI < minDist:
                    minDist = distJI
                    preds[i] = j
        return preds

    def avg(self, class_set):
        length = len(class_set)
        assert length >= 1
        if(length == 1):
            return 0.0
        sum = 0.0
        for i in range(0, length):
            for j in range(i + 1, length):
                sum += self._distEclud(class_set[i], class_set[j])
        return 2.0 / (length * (length - 1)) * sum

    def diam(self, class_set):
        length = len(class_set)
        assert length >= 1
        if length == 1:
            return 0.0
        m_dis = self._distEclud(class_set[0], class_set[1])
        for i in range(0,length):
            for j in range(i + 1, length):
                m_dis = max(m_dis, self._distEclud(class_set[i], class_set[j]))
        return m_dis

    def min(self, class1_set, class2_set):
        length1 = len(class1_set); length2 = len(class2_set)
        min_dis = self._distEclud(class1_set[0], class2_set[0])
        for i in range(0, length1):
            for j in range(0, length2):
                min_dis = min(min_dis, self._distEclud(class1_set[i], class2_set[j]))
        return min_dis

    def cen(self, class1_set, class2_set):
        length1 = len(class1_set); length2 = len(class2_set)
        u1 = np.sum(class1_set) / length1
        u2 = np.sum(class2_set) / length2
        return self._distEclud(u1, u2)

    def DBI(self, C):
        k = len(C)
        sum = 0.0
        for i in range(0, k):
            maxvalue = - 1
            for j in range(0, k):
                if i == j:
                    continue
                maxvalue = max(maxvalue, (self.avg(C[i]) + self.avg(C[j])) / self.cen(C[i], C[j]))
            sum += maxvalue
        return sum / k

    def DI(self, C):
        length = len(C)
        min1 = sys.float_info[0]
        for i in range(0, length):
            min2 = sys.float_info[0]
            for j in range(0, length):
                if i == j :
                    continue
                max1 = -1.0
                for k in range(0, length):
                    max1 = max(max1, self.diam(C[k]))
                t = self.min(C[i], C[j])
                min2 = min(min2, self.min(C[i], C[j]) / max1)
            min1 = min(min1, min2)
        return min1





def readfromfile(filename, split):
    x = [];
    y = []
    map = {}
    num = 0
    for line in open(filename):
        t = line.strip().split(",")
        if split:
            x.append(list(float(t[i]) for i in range(0, len(t) - 1)))
            if map.get(t[len(t) - 1]) is None:
                map[t[len(t) - 1]] = num
                num += 1
            y.append(map[t[len(t) - 1]])
        else:
            x.append(list(float(t[i]) for i in range(0, len(t))))
    if split:
        return x, y
    else:
        return x, None
    pass


def cal_and_stat(predictor, data_set, k):
    predictor.n_clusters = k
    predictor.fit(data_set)
    labels = predictor.predict(data_set)
    labels = np.array(labels)
    C = []
    types = np.unique(labels)
    for i in range(0, len(types)):
        C.append(data_set[labels == types[i]])
    DBI = predictor.DBI(C)
    DI = predictor.DI(C)
    print "k = " + str(k) + "    DBI = " + str(DBI) + "    DI = " + str(DI)


def run(predictor, filename, flag):
    data_set, labels = readfromfile(filename, flag)
    data_set = np.array(data_set)
    if labels is not None:
        labels = np.array(labels)
        type_num = len(np.unique(labels))
    else:
        type_num = 2
    print filename + ":"
    for k in range(1, 4):
        cal_and_stat(predictor, data_set, k * type_num)



if __name__ == "__main__":
    predictor = KMeans()
    np.random.seed(0)
    run(predictor, "input/fourclass.csv", True)
    run(predictor, "input/glass.csv", True)
    run(predictor, "input/西瓜数据4.0.csv", False)
